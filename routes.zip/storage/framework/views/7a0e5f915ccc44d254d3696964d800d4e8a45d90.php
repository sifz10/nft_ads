<?php $__env->startSection('page_title'); ?>
Your Ads
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ads Details </h4>
                    </div>
                    <div class="card-body">
                        <div class="basic-list-group">
                            <ul class="list-group">
                                <li class="list-group-item active"> <b>Ad Name : </b> <?php echo e($ads->ads_name); ?> </li>
                                <li class="list-group-item"> <b>Ad Unique ID : </b> <?php echo e($ads->ads_id); ?>  </li>
                                <li class="list-group-item"> <b>Ad Title : </b> <?php echo e($ads->ads_title); ?>  </li>
                                <li class="list-group-item"> <b>Ad URL : </b> <?php echo e($ads->ads_url); ?>  </li>
                                <li class="list-group-item"> <b>Ad Budget : </b> <?php echo e($ads->ads_price); ?> tDBD </li>
                                <li class="list-group-item"> <b>Ad Banner : </b> <?php echo e($ads->ads_banner); ?>  </li>
                                <li class="list-group-item"> <b>Ad Description : </b> <?php echo e($ads->ads_desc); ?>  </li>
                                <li class="list-group-item"> <b>Ad Daily Budget : </b> <?php echo e($ads->ads_deaily_budget); ?> tDND </li>
                                <li class="list-group-item"> <b>Ad Daily Clicks : </b> <?php echo e($ads->ads_deaily_clicks); ?>  </li>
                                <li class="list-group-item"> <b>Ad Referral Website : </b> <?php echo e($ads->ads_referral_code); ?>  </li>
                                <li class="list-group-item"> <b>TxHash : </b> <?php echo e($ads->txHash); ?>  </li>
                                <li class="list-group-item"> <b>Status : </b> <?php echo e($ads->status); ?>  </li>
                                <li class="list-group-item"> <b>Created At : </b> <?php echo e($ads->created_at); ?>  </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\nftads\resources\views/font/ads/details.blade.php ENDPATH**/ ?>