<div class="deznav">
    <div class="deznav-scroll">
        <ul class="metismenu" id="menu">
            <li <?php if(Route::is('dashboard')): ?> class="mm-active active-no-child" <?php endif; ?>>
                <a class="has-arrow ai-icon" href="<?php echo route('dashboard'); ?>" aria-expanded="false">
                    <i class="flaticon-381-networking"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                </li>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-381-television"></i>
                        <span class="nav-text">Ads</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo route('create.ads'); ?>">Create Ads</a></li>
                        <li><a href="<?php echo route('dashboard.index.ads'); ?>">View Ads</a></li>
                    </ul>
                </li>
                <?php if(Auth::user()->role == "Admin"): ?>

                <li>
                    <a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-381-controls-3"></i>
                        <span class="nav-text">Settings</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo route('settings.index'); ?>">Generel Settings</a></li>
                        <li><a href="<?php echo route('index.ads'); ?>">Ads</a></li>
                        <li><a href="<?php echo route('index.users'); ?>">Users</a></li>
                    </ul>
                </li>
                <li>
                    <a class="has-arrow ai-icon" href="<?php echo route('ads.code'); ?>" aria-expanded="false">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" style="color: black" viewBox="" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-code">
                            <polyline points="16 18 22 12 16 6"></polyline>
                            <polyline points="8 6 2 12 8 18"></polyline>
                        </svg>
                        <span class="nav-text">Ads Code</span>
                    </a>
                    </li>
                    <?php endif; ?>

        </ul>
        <div class="copyright">
            <p><strong><?php echo e(env('APP_NAME')); ?> Dashboard</strong><br />© All Rights Reserved</p>
        </div>
    </div>
</div>
<?php /**PATH E:\Work\nftads\resources\views/components/dashboard/navbar/navbar.blade.php ENDPATH**/ ?>