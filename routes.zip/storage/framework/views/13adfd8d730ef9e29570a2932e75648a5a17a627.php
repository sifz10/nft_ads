
<?php $__env->startSection('page_title'); ?>
 Your Ads
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Your ads</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example4" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>Ads ID</th>
                                        <th>Title</th>
                                        <th>Link</th>
                                        <th>Budget </th>
                                        <th>Status </th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($ad->ads_id); ?></td>
                                        <td><?php echo e($ad->ads_title); ?></td>
                                        <td><?php echo e($ad->ads_url); ?></td>
                                        <td><?php echo e($ad->ads_price); ?> (tDND)</td>
                                        <?php if($ad->status == "Inactive"): ?>
                                          <td>
                                            <a class="btn btn-sm btn-danger" href="<?php echo route('payments.ads', $ad->id); ?>">
                                              <small>Pay Now</small>
                                            </a>
                                          </td>
                                        <?php else: ?>
                                          <td><span class="badge light badge-success">Active</span></td>
                                        <?php endif; ?>
                                        <td><?php echo e($ad->created_at->format('Y/d/m')); ?></td>
                                      </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\nftads\resources\views/font/ads/user_ads.blade.php ENDPATH**/ ?>