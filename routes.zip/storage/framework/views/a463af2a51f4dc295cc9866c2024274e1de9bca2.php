<?php $__env->startSection('page_title'); ?>
Users Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Users List</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example4" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>User No</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Email Verified</th>
                                        <th>Account Status</th>
                                        <th rowspan="2" class="d-flex justify-content-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="m-auto">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <?php if(!empty($user->email_verified_at)): ?>
                                        <td><span class="badge light badge-primary">Verified</span></td>
                                        <?php else: ?>
                                        <td><span class="badge light badge-danger">Not Verified</span></td>
                                        <?php endif; ?>
                                        <?php if($user->user_blocked == 1): ?>
                                        <td><span class="badge light badge-warning">Blocked</span></td>
                                        <?php else: ?>
                                        <td><span class="badge light badge-primary">Active</span></td>
                                        <?php endif; ?>
                                        <td>
                                            <div class="d-flex">
                                                <a href="<?php echo route('users.show', $user->id); ?>" title="Users Details" class="btn btn-info shadow btn-xs sharp mr-1"><i class="fa fa-eye"></i></a>

                                                <a href="<?php echo route('users.edit', $user->id); ?>" title="Edit Users" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-edit"></i></a>

                                                <?php if($user->user_blocked == 1): ?>
                                                  <a href="<?php echo route('users.blocked', $user->id); ?>" title="Unblock user" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-unlock"></i></a>
                                                <?php else: ?>
                                                  <a href="<?php echo route('users.blocked', $user->id); ?>" title="Block user" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-lock"></i></a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\nftads\resources\views/font/users/index.blade.php ENDPATH**/ ?>