
<?php $__env->startSection('page_title'); ?>
Users Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Users Details </h4>
                        <a href="<?php echo route('users.edit', $user->id); ?>" class="btn btn-sm btn-info">Edit</a>
                    </div>
                    <div class="card-body">
                        <div class="basic-list-group">
                            <ul class="list-group">
                                <li class="list-group-item active"> <b>Name : </b> <?php echo e($user->name); ?> </li>
                                <li class="list-group-item"> <b> Email : </b> <?php echo e($user->email); ?>  </li>
                                <li class="list-group-item"> <b> Email Varified : </b>
                                  <?php if($user->email_varified_at): ?>
                                  <span class="badge light badge-success">Verified</span>
                                  <?php else: ?>
                                  <span class="badge light badge-danger">Not Verified</span>
                                  <?php endif; ?>
                                </li>
                                <li class="list-group-item"> <b> Account Type : </b> <?php echo e($user->socialmedia->account_type); ?>  </li>
                                <li class="list-group-item"> <b> Wallet  : </b> <?php echo e($user->socialmedia->wallet); ?>  </li>
                                <li class="list-group-item"> <b> Facebook  : </b> <?php echo e($user->socialmedia->facebook_link); ?>  </li>
                                <li class="list-group-item"> <b> Twitter  : </b> <?php echo e($user->socialmedia->twitter_link); ?>  </li>
                                <li class="list-group-item"> <b> Instagram  : </b> <?php echo e($user->socialmedia->instagram_link); ?>  </li>
                                <li class="list-group-item"> <b> Ads By  <?php echo e($user->name); ?> : </b> <a href="<?php echo route('users.show.ads_by', [$user->name, $user->id]); ?>"> <?php echo e($user->ads->count()); ?> Ads </a> </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\nftads\resources\views/font/users/show.blade.php ENDPATH**/ ?>