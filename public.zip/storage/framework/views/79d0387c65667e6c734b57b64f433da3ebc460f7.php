
<?php $__env->startSection('page_title'); ?>
Users Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                  <div class="card-header">
                      <h4 class="card-title">Users Edit </h4>
                      <a href="<?php echo route('index.users'); ?>" class="btn btn-sm btn-danger">Back</a>
                  </div>
                  <script>
                    var loadFileOutput = function(event) {
                      var editoutput = document.getElementById('editoutput');
                      editoutput.src = URL.createObjectURL(event.target.files[0]);
                      editoutput.onload = function() {
                        URL.revokeObjectURL(editoutput.src) // free memory
                      }
                    };
                  </script>
                  <div class="card-body">
                    <form action="<?php echo route('users.update'); ?>" method="post" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                    <label for="">Name</label>
                    <input type="text" class="form-control mb-3" name="name" value="<?php echo e($user->name); ?>">
                    <label for="">Email</label>
                    <input type="text" disabled class="form-control mb-3" name="email" value="<?php echo e($user->email); ?>">
                    <img id="editoutput" src="<?php echo asset($user->profile_picture); ?>" width="140" height="140" style="border: 1px solid black;border-radius: 50%">
                    <br>
                    <br>
                    <div class="input-group mb-3">
                        <div class="custom-file">
                            <input type="file" name="avatar" onchange="loadFileOutput(event)" class="custom-file-input">
                            <label class="custom-file-label">Profile Image</label>
                        </div>
                    </div>
                    <?php
                      $user_social = $user->socialmedia;
                    ?>

                    <label for="">Wallet</label>
                    <input type="text" class="form-control mb-3" name="wallet" value="<?php if($user_social): ?> <?php echo e($user_social->wallet); ?> <?php endif; ?>">
                    <label for="">Instagram</label>
                    <input type="text" class="form-control mb-3" name="instagram_link" value="<?php if($user_social): ?> <?php echo e($user_social->instagram_link); ?> <?php endif; ?> ">
                    <label for="">Twitter</label>
                    <input type="text" class="form-control mb-3" name="twitter_link" value="<?php if($user_social): ?> <?php echo e($user_social->twitter_link); ?> <?php endif; ?>">
                    <label for="">Facebook</label>
                    <input type="text" class="form-control mb-3" name="facebook_link" value="<?php if($user_social): ?> <?php echo e($user_social->facebook_link); ?> <?php endif; ?>">
                    <button type="submit" class="btn btn-primary mt-3" name="button">Update</button>
                    </form>
                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\nftads\resources\views/font/users/edit.blade.php ENDPATH**/ ?>