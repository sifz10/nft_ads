<?php $__env->startSection('page_title'); ?>
Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="form-head d-flex mb-0 mb-lg-4 align-items-start">
            <div class="mr-auto d-none d-lg-block">
                <h2 class="text-black font-w600 mb-1">Dashboard</h2>
                <p class="mb-0">Welcome <b><?php echo e(Auth::user()->name); ?></b> to <?php echo e(env("APP_NAME")); ?> Dashboard</p>
            </div>
            <div class="d-none d-lg-flex align-items-center">
                <div class="text-right">
                    <h3 class="fs-20 text-black mb-0"><?php echo e(\Carbon\Carbon::now()->format("h:m A")); ?></h3>
                    <span class="fs-14"><?php echo e(\Carbon\Carbon::now()->format("D")); ?>, <?php echo e(\Carbon\Carbon::now()->format("d M Y")); ?></span>
                </div>
                <a class="ml-4 text-black p-3 rounded border text-center width60" href="#">
                    <i class="las la-cog scale5"></i>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-xxl-12">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Ads Overview</h4>
                            </div>
                            <div class="card-body">
                                <div id="flotLine1" class="flot-chart"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-xxl-12">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Ads Clicks</h4>
                            </div>
                            <div class="card-body">
                                <div id="line-chart-tooltips" class="ct-chart ct-golden-section chartlist-chart"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Ads Views</h4>
                            </div>
                            <div class="card-body">
                                <div id="overlapping-bars" class="ct-chart ct-golden-section chartlist-chart"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Your ads</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                          <table id="example4" class="display min-w850">
                              <thead>
                                  <tr>
                                      <th>Ads ID</th>
                                      <th>Title</th>
                                      <th>Link</th>
                                      <th>Budget </th>
                                      <th>Status </th>
                                      <th>Date</th>
                                  </tr>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <td><?php echo e($ad->ads_id); ?></td>
                                      <td><?php echo e($ad->ads_title); ?></td>
                                      <td><?php echo e($ad->ads_url); ?></td>
                                      <td><?php echo e($ad->ads_price); ?> (tDND)</td>
                                      <?php if($ad->status == "Inactive"): ?>
                                        <td>
                                          <a class="btn btn-sm btn-danger" href="<?php echo route('payments.ads', $ad->id); ?>">
                                            <small>Pay Now</small>
                                          </a>
                                        </td>
                                      <?php else: ?>
                                        <td><span class="badge light badge-success">Active</span></td>
                                      <?php endif; ?>
                                      <td><?php echo e($ad->created_at->format('Y/d/m')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                          </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\nftads\resources\views/dashboard.blade.php ENDPATH**/ ?>